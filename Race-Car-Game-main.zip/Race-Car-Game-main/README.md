# Race-Car-Game
Car racing game built entirely from scratch.

I am a 6th grader who is very interested in coding and want to take my skills to the next level.

How to play:

For this game you will need a Java IDE, such as Eclipse or Netbeans. To start, create a new project.
Next, create a package named com.sathvikkurap.CarGame (any other name works, but for that you will need to change the code for the files)
Then import/copy and paste the files into your project.
Finally add the images folder directly through File Explorer (or Finder if you're using a Mac).
And you're good to go! Run your program and you should see a car game running.

To control the car, use the left and right arrow keys to move your car. Hold the space key to go faster. And avoid the enemy cars.

I hope you liked my game. It would be great if you could star this repository. Thanks!
